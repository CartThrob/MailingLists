<?php

$config['cartthrob_mailing_list'] = [
    'other' => [],
    'fields' => [],
    'location_field' => [],
];
