<?php

class_alias('CartThrob\MailingLists\Module', 'Cartthrob_mailing_lists');